-- epub-fiction-fix.lua
--
-- A "fiction EPUB" cleanup filter tuned for Calibre-style split EPUBs:
--   * Remove in-book navigation/ToC pages and repeated nav lists.
--   * Promote faux headings to real divisions:
--       - Header(1) -> \part
--       - Header(2) -> \chapter
--       - Header(3) -> \section
--     (when used with top-level-division: part)
--   * Preserve original identifiers on promoted headings (keeps \label targets stable).
--   * Convert standalone asterisms ("* * *", "***", "⁂") to \scenebreak.
--   * Convert "inscription:" blocks into a memoir-friendly tabletcurse environment.
--   * Drop all images (covers, ornaments) by default.

local stringify = pandoc.utils.stringify

-- ---------- helpers ----------
local function trim(s)
  return (s:gsub("^%s+", ""):gsub("%s+$", ""))
end

local function squash(s)
  return trim((s or ""):gsub("%s+", " "))
end

local function lower(s)
  return (s or ""):lower()
end

local function has_letters(s)
  return (s or ""):match("%a") ~= nil
end

local function letters_count(s)
  local only = (s or ""):gsub("[^%a]", "")
  return #only
end

local function strip_double_braces(s)
  local t = squash(s)
  local inner = t:match("^%{%{(.+)%}%}$")
  if inner then return squash(inner) end
  return t
end

local function is_toc_title_text(s)
  local t = lower(squash(s))
  return t == "table of contents" or t == "contents"
end

local function is_scene_break_text(s)
  local t = squash(s)
  if t == "***" or t == "* * *" or t == "⁂" or t == "❦" then return true end
  -- short lines made only of separator-ish characters
  if #t <= 12 and t:match("^[%*%s%._~%-–—•·⋆⁂❦]+$") then return true end
  return false
end

local function normalize_target(href)
  -- "index_split_006.html#filepos626292" -> "index_split_006.html_filepos626292"
  if not href or href == "" then return nil end
  local h = href:gsub("^%./", "")
  h = h:gsub("#", "_")
  -- sometimes pandoc normalizes anchors with "filepos" already; keep as-is
  return h
end

-- Linky-nav detectors (for ToC removal)
local function block_has_internal_link(block)
  local found = false
  pandoc.walk_block(block, {
    Link = function(l)
      local t = l.target or ""
      if t:match("^#")
        or t:match("^index_split_%d+%.html")
        or t:match("%.x?html")
        or t:match("filepos%d+")
      then
        found = true
      end
      return l
    end
  })
  return found
end

local function list_is_nav(block)
  if block.t ~= "BulletList" and block.t ~= "OrderedList" then return false end
  local items = block.content
  if not items or #items < 4 then return false end
  for _, item in ipairs(items) do
    if #item < 1 then return false end
    local first = item[1]
    if not (first.t == "Para" or first.t == "Plain") then return false end
    if not block_has_internal_link(first) then return false end
  end
  return true
end

local function quote_is_nav(block)
  if block.t ~= "BlockQuote" then return false end
  for _, b in ipairs(block.content) do
    if list_is_nav(b) then return true end
    if (b.t == "Para" or b.t == "Plain") and block_has_internal_link(b) then return true end
  end
  return false
end

-- Parse a list item -> (title, target, children_list_block?)
local function first_link_in_blocks(blocks)
  local title, target = nil, nil
  for _, b in ipairs(blocks) do
    if b.t == "Para" or b.t == "Plain" then
      for _, il in ipairs(b.content) do
        if il.t == "Link" then
          title = squash(stringify(il.content))
          target = normalize_target(il.target)
          return title, target
        end
      end
    end
  end
  return nil, nil
end

local function get_child_list(blocks)
  -- In Pandoc AST, nested lists appear as a Block in the item's block list.
  for _, b in ipairs(blocks) do
    if b.t == "BulletList" or b.t == "OrderedList" then
      return b
    end
  end
  return nil
end

-- Extract ToC structure from the in-book ToC page (if present).
-- Returns:
--   toc_map[target_id] = { level = 2|3, title = "...", prefix = "1: " (optional) }
--   section_titles_by_chapter = { ["The Pilgrims"] = { "At the Inn", ... } }
local function extract_toc_maps(blocks)
  local toc_start = nil
  for i, b in ipairs(blocks) do
    if b.t == "Para" or b.t == "Plain" then
      if is_toc_title_text(stringify(b)) then
        toc_start = i
        break
      end
    elseif b.t == "Header" then
      if is_toc_title_text(stringify(b.content)) then
        toc_start = i
        break
      end
    end
  end
  if not toc_start then
    return {}, {}
  end

  local toc_map = {}
  local section_titles_by_chapter = {}

  -- Scan forward until content clearly stops being ToC-ish
  for i = toc_start, math.min(#blocks, toc_start + 600) do
    local b = blocks[i]
    if b.t == "OrderedList" or b.t == "BulletList" then
      -- This ToC style uses many smaller lists; accept even if < 4 items here.
      local items = b.content or {}
      for _, item in ipairs(items) do
        local title, target = first_link_in_blocks(item)
        if title and target then
          title = strip_double_braces(title)
          toc_map[target] = { level = 2, title = title }

          local child_list = get_child_list(item)
          if child_list then
            section_titles_by_chapter[title] = {}
            local citems = child_list.content or {}
            for idx, citem in ipairs(citems) do
              local ctitle, ctarget = first_link_in_blocks(citem)
              if ctitle and ctarget then
                ctitle = strip_double_braces(ctitle)
                -- If the child title doesn't already start with a digit, we add "N: " prefix
                local prefix = nil
                if not ctitle:match("^%d") then
                  prefix = tostring(idx) .. ": "
                end
                toc_map[ctarget] = { level = 3, title = ctitle, prefix = prefix, parent = title }
                table.insert(section_titles_by_chapter[title], ctitle)
              end
            end
          end
        end
      end
    end
  end

  return toc_map, section_titles_by_chapter
end

-- Heading inference for common Calibre EPUB patterns
local function looks_like_part_title(blocks, i)
  local b = blocks[i]
  local n = blocks[i + 1]
  if not b or not n then return false end
  if not (b.t == "Para" or b.t == "Plain") then return false end
  if n.t ~= "HorizontalRule" then return false end

  local t = strip_double_braces(stringify(b))
  if #t > 60 then return false end
  if not has_letters(t) then return false end
  if is_toc_title_text(t) then return false end
  return true
end

local function chapter_title_from_text(s)
  local t = strip_double_braces(squash(s))
  if t == "" then return nil end
  if not has_letters(t) then return nil end

  -- "1. TURJAN OF MIIR"
  local rest = t:match("^%d+%.%s*(.+)$")
  if rest and rest ~= "" then return squash(rest) end

  -- "CHAPTER IV: TITLE" or "CHAPTER IV TITLE"
  local rest2 = t:match("^[Cc][Hh][Aa][Pp][Tt][Ee][Rr]%s+[%w%.]+%s*[:%-%–]?%s*(.+)$")
  if rest2 and rest2 ~= "" then return squash(rest2) end

  -- Short ALL CAPS titles (with enough letters, avoid ornaments)
  if #t <= 80 and t == t:upper() and letters_count(t) >= 4 and not t:match("[%p]") then
    return t
  end

  -- Title case headings that look like actual chapters (keep as-is)
  if #t <= 70 and has_letters(t) then
    -- Reject obviously narrative paragraphs (lowercase + long)
    if #t <= 40 then
      return t
    end
  end

  return nil
end

local function section_title_from_text(s)
  local t = strip_double_braces(squash(s))
  if t == "" then return nil end
  if not has_letters(t) then return nil end

  -- "1 FLUTIC" or "2 THE INN OF BLUE LAMPS" -> "FLUTIC" / "THE INN OF BLUE LAMPS"
  local rest = t:match("^%d+%s+(.+)$")
  if rest and rest ~= "" then
    -- Only treat as section if the remaining looks like a heading (usually ALL CAPS in these EPUBs)
    if rest == rest:upper() and letters_count(rest) >= 4 then
      return squash(rest)
    end
  end

  return nil
end

-- Convert inscription blocks to \begin{tabletcurse}...\end{tabletcurse}
local function is_inscription_leadin_text(s)
  local t = lower(squash(s))
  return t:match("inscription%s*:") ~= nil
end

local function is_inscription_line_text(s)
  local t = strip_double_braces(squash(s))
  if t == "" then return false end
  -- allow punctuation and apostrophes; require at least 6 letters and mostly uppercase
  if letters_count(t) < 6 then return false end
  if t:match("%l") then return false end
  return true
end

local function make_header(level, title, attr)
  local inlines = pandoc.Inlines{ pandoc.Str(title) }
  return pandoc.Header(level, inlines, attr or pandoc.Attr())
end

-- ---------- main ----------
function Pandoc(doc)
  local blocks = doc.blocks

  -- Pre-scan the in-book ToC to learn nested chapter->section structure.
  local toc_map, toc_sections_by_chapter = extract_toc_maps(blocks)

  local out = {}
  local i = 1

  local skipping_toc_page = false
  local current_part = nil
  local current_chapter = nil

  while i <= #blocks do
    local b = blocks[i]

    -- Drop all images (covers, ornaments) in both block and inline contexts
    b = pandoc.walk_block(b, {
      Image = function(_) return {} end
    })

    -- Remove repeated in-book nav lists anywhere
    if list_is_nav(b) or quote_is_nav(b) then
      i = i + 1
      goto continue
    end

    -- Begin skipping the ToC page if we see its title
    if (b.t == "Para" or b.t == "Plain") and is_toc_title_text(stringify(b)) then
      skipping_toc_page = true
      i = i + 1
      goto continue
    end
    if b.t == "Header" and is_toc_title_text(stringify(b.content)) then
      skipping_toc_page = true
      i = i + 1
      goto continue
    end

    if skipping_toc_page then
      -- keep skipping until we stop seeing short headings and lists
      if (b.t == "Para" or b.t == "Plain") then
        local t = squash(stringify(b))
        if #t <= 90 then
          i = i + 1
          goto continue
        end
      end
      if b.t == "OrderedList" or b.t == "BulletList" or b.t == "BlockQuote" then
        i = i + 1
        goto continue
      end
      skipping_toc_page = false
      -- fall through and process b
    end

    -- Scene breaks
    if (b.t == "Para" or b.t == "Plain") and is_scene_break_text(stringify(b)) then
      table.insert(out, pandoc.RawBlock("latex", "\\scenebreak"))
      i = i + 1
      goto continue
    end

    -- Inscription/tablet blocks
    if (b.t == "Para" or b.t == "Plain") and is_inscription_leadin_text(stringify(b)) then
      -- keep the lead-in paragraph
      table.insert(out, b)

      local j = i + 1
      local lines = {}

      while j <= #blocks do
        local nb = blocks[j]

        -- stop at obvious prose
        if nb.t == "Para" or nb.t == "Plain" then
          local t = squash(stringify(nb))
          if is_scene_break_text(t) then
            -- separator -> blank line
            table.insert(lines, "")
            j = j + 1
          elseif is_inscription_line_text(t) then
            table.insert(lines, strip_double_braces(t))
            j = j + 1
          else
            break
          end
        else
          break
        end
      end

      if #lines > 0 then
        -- build LaTeX env with blank lines between entries
        local body = {}
        body[#body+1] = "\\begin{tabletcurse}"
        body[#body+1] = ""
        for _, ln in ipairs(lines) do
          if ln == "" then
            body[#body+1] = ""
          else
            body[#body+1] = "  " .. ln
            body[#body+1] = ""
          end
        end
        body[#body+1] = "\\end{tabletcurse}"
        table.insert(out, pandoc.RawBlock("latex", table.concat(body, "\n")))
      end

      i = j
      goto continue
    end

    -- PART inference: short title followed by horizontal rule
    if looks_like_part_title(blocks, i) then
      local title = strip_double_braces(stringify(b))
      local attr = b.attr or pandoc.Attr()
      current_part = title
      current_chapter = nil
      table.insert(out, make_header(1, title, attr))
      i = i + 2 -- skip HorizontalRule
      goto continue
    end

    -- Promote ToC-mapped anchors (preserve identifiers!)
    if (b.t == "Para" or b.t == "Plain") and b.attr and b.attr.identifier and b.attr.identifier ~= "" then
      local id = b.attr.identifier
      local entry = toc_map[id]
      if entry then
        local raw_title = strip_double_braces(stringify(b))
        local title = entry.title

        -- If the body heading has stronger capitalization (e.g., ALL CAPS), keep it.
        if raw_title ~= "" and raw_title == raw_title:upper() and letters_count(raw_title) >= 4 then
          title = raw_title
        end

        -- Apply numeric prefix (used for The Pilgrims sub-sections)
        if entry.level == 3 and entry.prefix and not title:match("^%d") then
          title = entry.prefix .. title
        end

        if entry.level == 2 then
          current_chapter = title
        end

        table.insert(out, make_header(entry.level, title, b.attr))
        i = i + 1
        goto continue
      end
    end

    -- SECTION inference from numeric ALLCAPS headings ("1 FLUTIC", "2 THE INN...")
    if (b.t == "Para" or b.t == "Plain") then
      local t = stringify(b)
      local st = section_title_from_text(t)
      if st then
        current_chapter = current_chapter -- unchanged
        table.insert(out, make_header(3, st, b.attr))
        i = i + 1
        goto continue
      end
    end

    -- SECTION inference using ToC child titles (title case, no numbering in EPUB)
    if current_chapter and toc_sections_by_chapter[current_chapter] and (b.t == "Para" or b.t == "Plain") then
      local bt = strip_double_braces(squash(stringify(b)))
      if bt ~= "" then
        local children = toc_sections_by_chapter[current_chapter]
        for idx, ct in ipairs(children) do
          if bt == ct then
            local title = bt
            -- If title isn't already numbered, add "N: " (matches your cleaned file)
            if not title:match("^%d") then
              title = tostring(idx) .. ": " .. title
            end
            table.insert(out, make_header(3, title, b.attr))
            i = i + 1
            goto continue
          end
        end
      end
    end

    -- CHAPTER inference
    if (b.t == "Para" or b.t == "Plain") then
      local t = stringify(b)
      local ct = chapter_title_from_text(t)
      if ct and ct ~= "" then
        current_chapter = ct
        table.insert(out, make_header(2, ct, b.attr))
        i = i + 1
        goto continue
      end
    end

    table.insert(out, b)
    i = i + 1

    ::continue::
  end

  doc.blocks = out
  return doc
end
